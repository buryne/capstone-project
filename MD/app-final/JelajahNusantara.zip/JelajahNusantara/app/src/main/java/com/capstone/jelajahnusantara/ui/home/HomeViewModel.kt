package com.capstone.jelajahnusantara.ui.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.capstone.jelajahnusantara.data.Preferences
import com.capstone.jelajahnusantara.data.repository.Repository
import com.capstone.jelajahnusantara.model.PostResponse
import com.capstone.jelajahnusantara.model.UserModel
import com.capstone.jelajahnusantara.utils.State
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: Repository
): ViewModel() {
    private val _posts = MutableStateFlow<State<List<PostResponse>>>(State.Loading())
    val posts = _posts.asStateFlow()
    private val _user = MutableStateFlow(UserModel())
    val user = _user.asStateFlow()

    init {
        getAllPosts()
        _user.value = repository.getSignedInUser()
    }

    private fun getAllPosts() {
        viewModelScope.launch {
            repository.getAllPosts().collect {
                _posts.value = it
            }
        }
    }

    fun logOut(context: Context) {
        Preferences.logOut(context)
    }
}