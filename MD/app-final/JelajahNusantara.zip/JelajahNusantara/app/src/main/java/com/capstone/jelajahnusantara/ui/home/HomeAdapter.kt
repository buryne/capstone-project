package com.capstone.jelajahnusantara.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.capstone.jelajahnusantara.databinding.ItemStoryBinding
import com.capstone.jelajahnusantara.model.PostResponse
import com.capstone.jelajahnusantara.utils.glide

class HomeAdapter: RecyclerView.Adapter<HomeAdapter.HomeViewBinding>() {

    inner class HomeViewBinding(val binding: ItemStoryBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(post: PostResponse) {
            with(binding) {
                tvLokasi.text = post.location
                tvUsername.text = post.title
                tvContent.text = post.description
                post.image?.let {
                    imgUser.glide(post.image)
                    circleImageView.glide(it)
                }
            }
        }
    }

    private val diffUtil = object: DiffUtil.ItemCallback<PostResponse>() {
        override fun areItemsTheSame(oldItem: PostResponse, newItem: PostResponse): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: PostResponse, newItem: PostResponse): Boolean {
            return oldItem == newItem
        }

    }

    val differ = AsyncListDiffer(this, diffUtil)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeViewBinding {
        return HomeViewBinding(
            ItemStoryBinding.inflate(
                LayoutInflater.from(parent.context), null, false
            )
        )
    }

    override fun getItemCount(): Int= differ.currentList.size

    override fun onBindViewHolder(holder: HomeViewBinding, position: Int) {
        val story = differ.currentList[position]
        holder.bind(story)
    }
}