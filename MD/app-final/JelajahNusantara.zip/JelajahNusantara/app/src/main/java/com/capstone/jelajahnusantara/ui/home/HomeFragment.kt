package com.capstone.jelajahnusantara.ui.home

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.asLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import com.capstone.jelajahnusantara.databinding.FragmentHomeBinding
import com.capstone.jelajahnusantara.model.UserModel
import com.capstone.jelajahnusantara.ui.login.LoginActivity
import com.capstone.jelajahnusantara.utils.State
import com.capstone.jelajahnusantara.utils.glide
import com.capstone.jelajahnusantara.utils.hide
import com.capstone.jelajahnusantara.utils.show
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val homeAdapter by lazy { HomeAdapter() }
    private val viewModel by viewModels<HomeViewModel>()
    private var user = UserModel()
    private lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater)
        return binding.root
    }

    @SuppressLint("SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = FirebaseAuth.getInstance()

        user = viewModel.user.value
        user.photoURL?.let { binding.ivProfil.glide(it) }
        user.displayName?.let { binding.tvHelloName.text = "Hi, $it" }
        binding.rvStory.apply {
            adapter = homeAdapter
            layoutManager = LinearLayoutManager(requireContext())
        }
        observer()

        binding.btnLogout.setOnClickListener {
            auth.signOut()
            viewModel.logOut(requireContext())
            startActivity(
                Intent(requireContext(), LoginActivity::class.java).also {
                    it.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
            requireActivity().finish()
        }
    }

    private fun observer() {
        val posts = viewModel.posts.asLiveData()
        posts.observe(viewLifecycleOwner) { state ->
            when(state) {
                is State.Loading -> {
                    binding.progressBar.show()
                }
                is State.Success -> {
                    binding.progressBar.hide()
                    state.data?.let {
                        homeAdapter.differ.submitList(it)
                    }
                }
                is State.Error -> {
                    binding.progressBar.hide()
                    Toast.makeText(requireContext(), state.error.toString(), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}