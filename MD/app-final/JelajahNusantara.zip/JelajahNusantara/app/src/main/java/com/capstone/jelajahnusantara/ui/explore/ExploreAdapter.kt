package com.capstone.jelajahnusantara.ui.explore

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.capstone.jelajahnusantara.databinding.ItemLocationBinding
import com.capstone.jelajahnusantara.model.RekomendasiResponse

class ExploreAdapter: RecyclerView.Adapter<ExploreAdapter.ExploreViewBinding>() {

    inner class ExploreViewBinding(val binding: ItemLocationBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(rekomendasi: RekomendasiResponse) {
            with(binding) {
                tvLocationTitle.text = rekomendasi.placeName
                tvLocationDetail.text = rekomendasi.city

                val firstIndex = rekomendasi.rating.toString().first()
                val lastIndex = rekomendasi.rating.toString().last()
                val rating = "$firstIndex,$lastIndex"
                tvRating.text = rating
            }
        }
    }

    private val diffUtil = object: DiffUtil.ItemCallback<RekomendasiResponse>() {
        override fun areItemsTheSame(oldItem: RekomendasiResponse, newItem: RekomendasiResponse): Boolean {
            return oldItem.placeName == newItem.placeName
        }

        override fun areContentsTheSame(oldItem: RekomendasiResponse, newItem: RekomendasiResponse): Boolean {
            return oldItem == newItem
        }

    }

    val differ = AsyncListDiffer(this, diffUtil)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExploreViewBinding {
        return ExploreViewBinding(
            ItemLocationBinding.inflate(
                LayoutInflater.from(parent.context), null, false
            )
        )
    }

    override fun getItemCount(): Int= differ.currentList.size

    override fun onBindViewHolder(holder: ExploreViewBinding, position: Int) {
        val story = differ.currentList[position]
        holder.bind(story)

        val context = holder.itemView.context
        holder.itemView.setOnClickListener {
            context.startActivity(
                Intent(context, DetailExploreActivity::class.java).also {
                    it.putExtra("rekomendasi", story)
                }
            )
        }
    }
}