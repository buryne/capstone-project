package com.capstone.jelajahnusantara.ui.firstsetup

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.capstone.jelajahnusantara.MainActivity
import com.capstone.jelajahnusantara.databinding.ActivityFirstSetupBinding

class FirstSetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFirstSetupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFirstSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.cvBandung.setOnClickListener {
            setLocation("Bandung")
        }
        binding.cvJakarta.setOnClickListener {
            setLocation("Jakarta")
        }
        binding.cvSemarang.setOnClickListener {
            setLocation("Semarang")
        }
        binding.cvSurabaya.setOnClickListener {
            setLocation("Surabaya")
        }
        binding.cvYogyakarta.setOnClickListener {
            setLocation("Yogyakarta")
        }
    }

    private fun setLocation(location: String) {
        val sharedPref = getSharedPreferences("location", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()
        editor.putString("location", location)
        editor.apply()

        startActivity(
            Intent(this, MainActivity::class.java)
        )
        finish()
    }
}