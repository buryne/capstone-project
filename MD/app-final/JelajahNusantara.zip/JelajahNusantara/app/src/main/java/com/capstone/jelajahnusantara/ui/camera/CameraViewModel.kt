package com.capstone.jelajahnusantara.ui.camera

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.capstone.jelajahnusantara.data.repository.Repository
import com.capstone.jelajahnusantara.model.PostResponse
import com.capstone.jelajahnusantara.utils.State
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class CameraViewModel @Inject constructor(
    private val repository: Repository
) : ViewModel() {
    private val _postStory = MutableStateFlow<State<PostResponse>>(State.Loading())
    val postStory = _postStory.asStateFlow()

    fun postStory(
        image: File,
        title: String,
        location: String,
        caption: String
    ) {
        viewModelScope.launch {
            repository.postStory(
                image, title, location, caption
            ).collect {
                _postStory.value = it
            }
        }
    }
}