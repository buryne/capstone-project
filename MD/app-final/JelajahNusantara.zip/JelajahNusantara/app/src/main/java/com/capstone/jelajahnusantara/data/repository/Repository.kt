package com.capstone.jelajahnusantara.data.repository

import android.content.Context
import com.capstone.jelajahnusantara.data.Preferences
import com.capstone.jelajahnusantara.data.retrofit.ApiService
import com.capstone.jelajahnusantara.data.retrofit.MLApiService
import com.capstone.jelajahnusantara.model.ErrorResponse
import com.capstone.jelajahnusantara.model.PostResponse
import com.capstone.jelajahnusantara.model.RekomendasiResponse
import com.capstone.jelajahnusantara.model.UserModel
import com.capstone.jelajahnusantara.utils.Constants
import com.capstone.jelajahnusantara.utils.State
import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import java.io.File

class Repository(
    private val apiService: ApiService,
    private val mlApiService: MLApiService,
    private val context: Context
) {
    private val _posts = MutableStateFlow<State<List<PostResponse>>>(State.Loading())
    private val _recommendations = MutableStateFlow<State<List<RekomendasiResponse>>>(State.Loading())
    private val _postById = MutableStateFlow<State<PostResponse>>(State.Loading())
    private val _actionPost = MutableStateFlow<State<PostResponse>>(State.Loading())

    suspend fun getAllPosts(): Flow<State<List<PostResponse>>> {
        try {
            val client = apiService.getAllPosts()
            if (client.isSuccessful) {
                val listPosts = client.body()
                listPosts?.let {
                    _posts.value = State.Success(it)
                }
            } else {
                throw HttpException(client)
            }
        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
            val errorMessage = errorBody.message
            _posts.value = State.Error(errorMessage.toString())
        }

        return _posts.asStateFlow()
    }

    suspend fun getAllRecommendations(nama: String): Flow<State<List<RekomendasiResponse>>> {
        try {
            val client = mlApiService.getAllPosts(nama)
            if (client.isSuccessful) {
                val listPosts = client.body()
                listPosts?.let {
                    _recommendations.value = State.Success(it)
                }
            } else {
                throw HttpException(client)
            }
        } catch (e: HttpException) {
            _recommendations.value = State.Error(e.message())
        }

        return _recommendations.asStateFlow()
    }

    suspend fun getPostById(id: String): Flow<State<PostResponse>> {
        try {
            val client = apiService.getPostById(id)
            if (client.isSuccessful) {
                val post = client.body()
                post?.let {
                    _postById.value = State.Success(it)
                }
            } else {
                throw HttpException(client)
            }
        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
            val errorMessage = errorBody.message
            _postById.value = State.Error(errorMessage.toString())
        }

        return _postById.asStateFlow()
    }

    suspend fun postStory(
        image: File,
        title: String,
        location: String,
        caption: String
    ): Flow<State<PostResponse>> {
        val requestImageFile = image.asRequestBody("image/*".toMediaType())
        val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
            "image",
            image.name,
            requestImageFile
        )
        val tagsCast = "".toRequestBody("application/json".toMediaType())

        val titleCast = title.toRequestBody("text/plain".toMediaType())
        val locationCast = location.toRequestBody("text/plain".toMediaType())
        val captionCast = caption.toRequestBody("text/plain".toMediaType())

        try {
            val client = apiService.postStory(
                titleCast,
                locationCast,
                captionCast,
                tagsCast,
                imageMultipart
            )
            if (client.isSuccessful) {
                val listPosts = client.body()
                listPosts?.let {
                    _actionPost.value = State.Success(it)
                }
            } else {
                throw HttpException(client)
            }
        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
            val errorMessage = errorBody.message
            _actionPost.value = State.Error(errorMessage.toString())
        }

        return _actionPost.asStateFlow()
    }

    fun getSignedInUser(): UserModel {
        val sharedPref = Preferences.init(context, "session")
        val userId = sharedPref.getString(Constants.USER_ID, "")
        val name = sharedPref.getString(Constants.NAME, "")
        val email = sharedPref.getString(Constants.EMAIL, "")
        val avatar = sharedPref.getString(Constants.PHOTO_URL, "")

        return UserModel(
            displayName = name,
            uid = userId,
            email = email,
            photoURL = avatar
        )
    }

    fun getLocation(): String {
        val sharedPref = context.getSharedPreferences("location", Context.MODE_PRIVATE)
        val location = sharedPref.getString("location", "Jakarta")

        return location ?: "Jakarta"
    }
}