package com.capstone.jelajahnusantara.data.retrofit

import com.capstone.jelajahnusantara.model.RekomendasiResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface MLApiService {

    @GET("predict")
    suspend fun getAllPosts(
        @Query("name") namaKota: String
    ): Response<List<RekomendasiResponse>>
}