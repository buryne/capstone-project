package com.capstone.jelajahnusantara.ui.camera

import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.asLiveData
import com.capstone.jelajahnusantara.R
import com.capstone.jelajahnusantara.databinding.FragmentCameraBinding
import com.capstone.jelajahnusantara.utils.Constants.PERMISSIONS
import com.capstone.jelajahnusantara.utils.State
import com.capstone.jelajahnusantara.utils.hide
import com.capstone.jelajahnusantara.utils.setUpCamera
import com.capstone.jelajahnusantara.utils.show
import com.capstone.jelajahnusantara.utils.showPermissionSettingsAlert
import com.capstone.jelajahnusantara.utils.uriToFile
import dagger.hilt.android.AndroidEntryPoint
import java.io.File

@AndroidEntryPoint
class CameraFragment : Fragment() {

    private lateinit var binding: FragmentCameraBinding
    private val viewModel by viewModels<CameraViewModel>()
    private var photoPath: String? = null
    private var imageFile: File? = null
    private var permissionGiven: Boolean? = null

    private val permission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            val isGranted = permissions[Manifest.permission.CAMERA] ?: false
            val readData = permissions[Manifest.permission.READ_EXTERNAL_STORAGE] ?: false

            if (isGranted && readData) {
                permissionGiven = true
            }
        }

    private fun permissionSet() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionGiven = true
        } else {
            permission.launch(PERMISSIONS)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentCameraBinding.inflate(inflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        permissionSet()
        setActions()
        observer()
    }

    private fun setActions() {
        binding.cameraBtn.setOnClickListener {
            permissionGiven?.let {
                if (it) {
                    startCamera()
                } else {
                    showPermissionSettingsAlert(requireContext())
                }
            }
        }
        binding.galleryBtn.setOnClickListener {
            val chooser = setUpGallery()
            launchGallery.launch(chooser)
        }
        binding.uploadBtn.setOnClickListener {
            val title = binding.etTitle.text.toString()
            val caption = binding.etCaption.text.toString()
            val location = binding.etLocation.text.toString()
            if (imageFile == null && title.isEmpty() && caption.isEmpty() && location.isEmpty()) {
                Toast.makeText(requireContext(), "Harap isi semua", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            imageFile?.let {
                viewModel.postStory(
                    it, title, location, caption
                )
                binding.progressBar.show()
            }
        }
    }

    private fun observer() {
        val postState = viewModel.postStory.asLiveData()
        postState.observe(viewLifecycleOwner) {
            when (it) {
                is State.Loading -> {}
                is State.Success -> {
                    binding.progressBar.hide()
                    binding.etTitle.setText("")
                    binding.etCaption.setText("")
                    binding.etLocation.setText("")
                    binding.ivPhoto.setImageResource(R.drawable.background)
                    Toast.makeText(requireContext(), "Berhasil membuat post", Toast.LENGTH_SHORT)
                        .show()
                }

                is State.Error -> {
                    binding.progressBar.hide()
                    Toast.makeText(requireContext(), it.error.toString(), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun startCamera() {
        val intent = requireActivity().setUpCamera()
        photoPath = intent.path
        launchCamera.launch(intent.intent)
    }

    private val launchCamera = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == AppCompatActivity.RESULT_OK) {
            val myFile = File(photoPath!!)

            myFile.let { file ->
                imageFile = file
                binding.ivPhoto.setImageBitmap(BitmapFactory.decodeFile(file.path))
            }
        }
    }

    private fun setUpGallery(): Intent {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        return Intent.createChooser(intent, "Choose a Picture")
    }

    private val launchGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val selectedImg = result.data?.data as Uri
            selectedImg.let { uri ->
                val myFile = uriToFile(uri, requireContext())
                imageFile = myFile
                binding.ivPhoto.setImageURI(uri)
            }
        }
    }
}