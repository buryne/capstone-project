package com.capstone.jelajahnusantara.ui.explore

import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.capstone.jelajahnusantara.databinding.ActivityDetailExploreBinding
import com.capstone.jelajahnusantara.model.RekomendasiResponse

class DetailExploreActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailExploreBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailExploreBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("rekomendasi", RekomendasiResponse::class.java)
        } else {
            intent.getParcelableExtra("rekomendasi")
        }

        data?.let { rekom ->
            with(binding) {
                tvNamaLokasi.text = rekom.placeName
                tvLokasi.text = rekom.city
                tvDetail.text = rekom.description

                val firstIndex = rekom.rating.toString().first()
                val rating = firstIndex.toFloat()

                ratingBar.rating = rating
            }
        }
    }
}