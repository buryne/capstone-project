package com.capstone.jelajahnusantara.data.retrofit

import com.capstone.jelajahnusantara.model.PResponse
import com.capstone.jelajahnusantara.model.PostResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path

interface ApiService {

    @GET("posts")
    suspend fun getAllPosts(): Response<List<PostResponse>>

    @GET("posts/{id}")
    suspend fun getPostById(
        @Path("id") id: String? = null
    ): Response<PostResponse>

    @Multipart
    @POST("posts")
    suspend fun postStory(
        @Part("title") title: RequestBody,
        @Part("location") location: RequestBody,
        @Part("caption") caption: RequestBody,
        @Part("tags") tags: RequestBody,
        @Part image: MultipartBody.Part
    ): Response<PostResponse>
}