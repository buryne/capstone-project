package com.capstone.jelajahnusantara.model

import com.google.gson.annotations.SerializedName

data class UserResponse(
    @SerializedName("users")
    val users: List<User>?
)
data class User(
    @SerializedName("uid")
    val uid: String? = null,

    @SerializedName("displayName")
    val displayName: String? = null,

    @SerializedName("email")
    val email: String? = null,

    @SerializedName("photoURL")
    val photoURL: String? = null,

    @SerializedName("provider")
    val provider: String? = null,

    @SerializedName("verified")
    val verified: Boolean? = null,

    @SerializedName("posts")
    val posts: List<String>? = null
)

data class ErrorResponse(
    @SerializedName("message")
    val message: String?,
    @SerializedName("error")
    val error: String?
)

data class UserModel(
    val displayName: String? = null,
    val email: String? = null,
    val photoURL: String? = null,
    val uid: String? = null
)