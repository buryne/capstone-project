package com.capstone.jelajahnusantara.ui.login

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.capstone.jelajahnusantara.MainActivity
import com.capstone.jelajahnusantara.R
import com.capstone.jelajahnusantara.data.Preferences
import com.capstone.jelajahnusantara.databinding.ActivityLoginBinding
import com.capstone.jelajahnusantara.ui.firstsetup.FirstSetupActivity
import com.capstone.jelajahnusantara.utils.GoogleAuthUiClient
import com.google.android.gms.auth.api.identity.Identity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private val binding: ActivityLoginBinding by lazy {
        ActivityLoginBinding.inflate(layoutInflater)
    }
    private lateinit var auth: FirebaseAuth

    private val googleAuthUiClient by lazy {
        GoogleAuthUiClient(
            Identity.getSignInClient(applicationContext)
        )
    }

    private val launcher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            lifecycleScope.launch {
                val signInResult = googleAuthUiClient.signInWithIntent(result.data ?: return@launch)
                signInResult.data?.let { user ->
                    Preferences.saveToken(
                        user.displayName!!,
                        user.email!!,
                        user.photoURL!!,
                        user.uid!!,
                        this@LoginActivity
                    )
                    startActivity(
                        Intent(this@LoginActivity, FirstSetupActivity::class.java).also {
                            it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    )
                }
            }
        }else {
            binding.progressBar.visibility = View.GONE
            binding.googleButton.text = getString(R.string.masuk_dengan_google)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        auth = FirebaseAuth.getInstance()

        binding.googleButton.setOnClickListener {
            googleSignIn()
        }
    }

    private fun googleSignIn() {
        lifecycleScope.launch {
            binding.googleButton.text = ""
            binding.progressBar.visibility = View.VISIBLE
            val signInIntentSender = googleAuthUiClient.signIn()
            launcher.launch(
                IntentSenderRequest.Builder(
                    signInIntentSender ?: return@launch
                ).build()
            )
        }
    }

    override fun onStart() {
        super.onStart()
        if (auth.currentUser != null) {
            Intent(this, FirstSetupActivity::class.java).also { intent ->
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
        }
    }
}
