package com.capstone.jelajahnusantara.model

import com.google.gson.annotations.SerializedName

data class PResponse(
    val message: String? = null,
    val allData: Int? = null,
    val count: Int? = null,
    @field:SerializedName("data")
    val data: List<PostResponse>? = null
)

data class PostResponse(
    val id: String? = null,
    @SerializedName("image")
    val image: String? = null,
    val title: String? = null,
    val location: String? = null,
    @SerializedName("caption")
    val description: String? = null,
    val displayName: String?,
    val user: UsersPost? = null,
    @SerializedName("photoURL")
    val photoURL: String?,
    val userId: String? = null
)

data class UsersPost(
    @SerializedName("displayName")
    val displayName: String?,

    @SerializedName("email")
    val email: String?,

    @SerializedName("photoURL")
    val photoURL: String?,

    @SerializedName("uid")
    val uid: String?
)