package com.capstone.jelajahnusantara.di

import android.content.Context
import com.capstone.jelajahnusantara.data.repository.Repository
import com.capstone.jelajahnusantara.data.retrofit.ApiService
import com.capstone.jelajahnusantara.data.retrofit.MLApiService
import com.capstone.jelajahnusantara.utils.Constants.BASE_URL
import com.capstone.jelajahnusantara.utils.Constants.ML_BASE_URL
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideApiService(): ApiService {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(
                OkHttpClient.Builder()
                    .addInterceptor(
                        HttpLoggingInterceptor().setLevel(
                            HttpLoggingInterceptor.Level.BODY
                        )
                    )
                    .build()
            )
            .build()
            .create(ApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideMlApiService(): MLApiService {
        return Retrofit.Builder()
            .baseUrl(ML_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(
                OkHttpClient.Builder()
                    .addInterceptor(
                        HttpLoggingInterceptor().setLevel(
                            HttpLoggingInterceptor.Level.BODY
                        )
                    )
                    .build()
            )
            .build()
            .create(MLApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideRepository(
        apiService: ApiService,
        @ApplicationContext context: Context,
        mlApiService: MLApiService
    ): Repository = Repository(apiService, mlApiService, context)
}