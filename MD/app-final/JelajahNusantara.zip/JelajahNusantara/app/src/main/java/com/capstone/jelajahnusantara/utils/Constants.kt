package com.capstone.jelajahnusantara.utils

import android.Manifest

object Constants {
    const val WEB_CLIENT_ID = "216854684976-pjjp028222pt8k5tccehbfdc2bppnur2.apps.googleusercontent.com"
    const val SESSION = "session"
    const val USER_ID = "user_id"
    const val NAME = "name"
    const val EMAIL = "email"
    const val PHOTO_URL = "photo_url"
    const val BASE_URL = "https://capstone-project-api-ch2-ps352.et.r.appspot.com/api/"
    const val ML_BASE_URL = "https://model-api-dot-capstone-project-api-ch2-ps352.et.r.appspot.com/janu-recomend/"
    val PERMISSIONS = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
}