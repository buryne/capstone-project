package com.capstone.jelajahnusantara.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class RekomendasiResponse(
    @field:SerializedName("Category")
    val category: String? = null,
    @field:SerializedName("City")
    val city: String? = null,
    @field:SerializedName("Description")
    val description: String? = null,
    @field:SerializedName("Place_Id")
    val placeId: Int? = null,
    @field:SerializedName("Place_Name")
    val placeName: String? = null,
    @field:SerializedName("Price")
    val price: Int? = null,
    @field:SerializedName("Rating")
    val rating: Int? = null,
): Parcelable
