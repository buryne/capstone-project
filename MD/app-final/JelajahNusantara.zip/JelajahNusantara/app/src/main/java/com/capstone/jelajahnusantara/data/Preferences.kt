package com.capstone.jelajahnusantara.data

import android.content.Context
import android.content.SharedPreferences
import com.capstone.jelajahnusantara.utils.Constants.EMAIL
import com.capstone.jelajahnusantara.utils.Constants.NAME
import com.capstone.jelajahnusantara.utils.Constants.PHOTO_URL
import com.capstone.jelajahnusantara.utils.Constants.SESSION
import com.capstone.jelajahnusantara.utils.Constants.USER_ID

object Preferences {
    fun init(context: Context, name: String): SharedPreferences {
        return context.getSharedPreferences(name, Context.MODE_PRIVATE)
    }

    private fun preferenceEditor(context: Context): SharedPreferences.Editor {
        val sharedPref = context.getSharedPreferences(SESSION, Context.MODE_PRIVATE)
        return sharedPref.edit()
    }

    fun saveToken(name: String, email: String,avatar: String, userId: String, context: Context) {
        val editor = preferenceEditor(context)
        editor.putString(USER_ID, userId)
        editor.putString(NAME, name)
        editor.putString(EMAIL, email)
        editor.putString(PHOTO_URL, avatar)
        editor.apply()
    }

    fun logOut(context: Context) {
        val editor = preferenceEditor(context)
        editor.remove(USER_ID)
        editor.remove(NAME)
        editor.remove(EMAIL)
        editor.remove(PHOTO_URL)
        editor.remove("status")
        editor.apply()
    }
}