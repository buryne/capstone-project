package com.capstone.jelajahnusantara.ui.explore

import androidx.core.util.lruCache
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.capstone.jelajahnusantara.data.repository.Repository
import com.capstone.jelajahnusantara.model.RekomendasiResponse
import com.capstone.jelajahnusantara.utils.State
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ExploreViewModel @Inject constructor(
    private val repository: Repository
): ViewModel() {
    private val _recommendations = MutableStateFlow<State<List<RekomendasiResponse>>>(State.Loading())
    val recommendations = _recommendations.asStateFlow()
    val location = repository.getLocation()

    init {
        getRecommendations(location)
    }

    fun getRecommendations(loc: String) {
        viewModelScope.launch {
            repository.getAllRecommendations(loc).collect {
                _recommendations.value = it
            }
        }
    }
}