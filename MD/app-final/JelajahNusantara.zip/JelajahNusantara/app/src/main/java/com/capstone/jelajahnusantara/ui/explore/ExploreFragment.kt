package com.capstone.jelajahnusantara.ui.explore

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.asLiveData
import androidx.recyclerview.widget.GridLayoutManager
import com.capstone.jelajahnusantara.databinding.FragmentExploreBinding
import com.capstone.jelajahnusantara.utils.State
import com.capstone.jelajahnusantara.utils.hide
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ExploreFragment : Fragment() {

    private lateinit var binding: FragmentExploreBinding
    private val exploreAdapter by lazy { ExploreAdapter() }
    private val viewModel by viewModels<ExploreViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentExploreBinding.inflate(inflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.recyclerView.apply {
            adapter = exploreAdapter
            layoutManager = GridLayoutManager(requireContext(), 2)
        }
        setUpSearchBar()
        observer()
    }

    private fun setUpSearchBar() {
        binding.apply {
            searchView.setupWithSearchBar(searchBar)
            searchView.editText.setOnEditorActionListener { _, _, _ ->
                searchView.hide()
                viewModel.getRecommendations(searchView.text.toString())
                false
            }
        }
    }

    private fun observer() {
        val recommendations = viewModel.recommendations.asLiveData()
        recommendations.observe(viewLifecycleOwner) { state ->
            when (state) {
                is State.Loading -> {}
                is State.Success -> {
                    binding.progressBar.hide()
                    state.data?.let {
                        exploreAdapter.differ.submitList(it)
                    }
                }
                is State.Error -> {
                    binding.progressBar.hide()
                    Toast.makeText(requireContext(), "Kota belum terdaftar", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}