package com.capstone.jelajahnusantara.utils

sealed class State<T>(
    val data: T? = null,
    val error: String? = null
){
    class Success<T>(data: T): State<T>(data)
    class Error<T>(error: String): State<T>(error = error)
    class Loading<T>: State<T>()

}