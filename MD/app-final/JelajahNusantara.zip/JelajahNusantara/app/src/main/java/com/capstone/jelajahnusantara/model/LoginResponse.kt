package com.capstone.jelajahnusantara.model

import com.google.gson.annotations.SerializedName

data class LoginResponse(
    @SerializedName("success")
    val success: Boolean,

    @SerializedName("token")
    val token: String?,

    @SerializedName("users")
    val user: Users?,

    @SerializedName("error")
    val error: String?
) {
    data class Users(
        @SerializedName("userId")
        val userId: String?,

        @SerializedName("username")
        val username: String?,

        // Properti lainnya yang mungkin diperlukan
    )
}
